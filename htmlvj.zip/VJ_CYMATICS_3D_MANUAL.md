# VJ Cymatics 3D Manual

Last updated: 2026-06-11

VJ Cymatics 3D is a browser-based audio and video reactive visualizer. It uses microphone or audio file input, real-time frequency analysis, Three.js particles and geometry, webcam or video depth processing, background shaders, post effects, MIDI control, gamepad control, and Auto VJ performance logic.

This manual is written for live use. Start with Quick Start, then use the later sections when you want to prepare presets, controllers, or troubleshoot.

## 1. Quick Start

1. Open `vj-final.html` in a modern browser.
2. Click `Mic` or choose an `Audio File`.
3. Turn on one or more `Visualization Modes`.
4. Adjust `Particle Count`, `Particle Size`, `Glow Strength`, and `Spark Power`.
5. Turn on `BG Enabled` and choose a `BG Mode` if you want a full-screen background layer.
6. Use `Effects` for Kaleidoscope, Glitch, RGB Shift, Grunge, Earthquake, Zoom, and Mirror.
7. Click `Save` when you like the setup.

Recommended browser: Chrome on desktop.

For AI Image generation, use the local server:

```sh
npm start
```

Then open:

```text
http://localhost:5173/vj-final.html
```

## 2. Screen Layout

The main canvas is the performance screen.

The `Control Panel` is the operation menu. It can be dragged by its header, minimized, or popped out into a separate control window.

Use the popout button in the panel header to open the controls in another window. In the popout window, `Hide Main` removes the menu from the main visual screen, and `Show Main` brings it back.

## 3. Audio Input

### Mic

`Mic` activates the microphone. Browser permission is required.

The audio is separated into:

- `Bass`: low frequencies, kick and sub movement
- `Mid`: body, voice, synth, melodic pressure
- `Treble`: hats, noise, sparkles, attacks

### Audio File

`Audio File` loads local audio files such as MP3, WAV, OGG, or browser-supported audio formats.

### Mic Sensitivity

Raises or lowers microphone gain for the visualizer. If the meters barely move, raise this. If everything is always reacting too hard, lower it.

### Noise Gate

Cuts low-level room noise from the microphone input. Raise it when the visuals react even in silence. Lower it when quiet music is not being detected.

## 4. Auto VJ

`Auto Performance` automatically changes modes, BG, and effects based on detected audio energy and BPM.

### Auto Range

- `Curated`: stable set for normal live use
- `Wide`: chooses from almost all modes
- `Chaos`: stronger random operation using all Mode and BG choices

### Auto Intensity

Controls how aggressively Auto VJ changes and pushes effects.

### Scene Pace

Controls how quickly scenes change. Lower values are calmer. Higher values are more active.

## 5. Live Safety

### FPS, Load, Quality

Use this section to judge whether the scene is too heavy.

- `Stable`: safe for performance
- `Busy`: still usable, but watch it
- `Heavy`: reduce load

### Safe Mode

Safe Mode applies performance caps. Use it when the frame rate drops or when projecting on a less powerful computer.

Safe Mode reduces or limits:

- Particle count
- Stardust count
- Video processing resolution
- Renderer pixel ratio
- Glow strength
- Bloom pass cost

### Panic

`Panic` returns the app to a safer state:

- Auto VJ off
- Safe Mode on
- BG off
- Modes reduced to Particles
- Heavy effects reset

Use this if the screen gets too chaotic or performance drops badly.

### Check

`Check` runs browser capability checks and shows status chips in the panel.

## 6. Visualization Modes

Modes are the foreground visual layers. Multiple modes can be active together.

### Core

- `Particles`
- `Stardust`
- `Wave`
- `Spiral`
- `Emitter`

### Webcam

These use `Webcam` or `Video File` input. If no video input is active, they show a fallback animated pattern so the screen does not go black.

- `Video`: brightness-to-depth particle video
- `Webcam Depth Cloud`: soft depth cloud
- `Webcam Neon Edge`: edge-detected neon outline
- `Webcam Thermal`: heat-map color response
- `Webcam Kaleido`: folded webcam pattern
- `Webcam Silhouette`: thresholded body and outline style
- `Webcam Liquid`: fluid distorted video particles
- `Webcam Voxel`: blocky stepped depth view
- `Webcam Ghost Delay`: delayed echo/trail video particles

When `Auto Rotation` is off, Webcam modes do not rotate by themselves.

### Geometry

- `Torus`
- `TorusKnot`
- `Icosahedron`
- `Octahedron`
- `Dodecahedron`
- `Sphere Mesh`
- `Triangle`
- `Orbit System`
- `Cymatic Plate`
- `Knot Cloud`

### Fractal

- `Fractal Tree`
- `Infinite Fractal`
- `Julia Geodes`
- `Flower Mandala`
- `Magic Circles`
- `Star Gate`
- `Black Hole`

### Energy

- `Laser Grid`
- `DNA Helix`
- `Plasma Ball`
- `Shard Burst`
- `Ribbon Flow`
- `Vortex Echo`
- `Particle Fountain`
- `Electric Web`
- `Pulse Rings`
- `Comet Field`

### Worlds

- `Crown`
- `Nebula`
- `Crystal Cave`
- `Audio Tunnel`
- `Rain Matrix`
- `Liquid Metal`
- `Wire Mountain`
- `Solar Flare`
- `Cathedral Lines`
- `Mirror City`
- `Data Storm`

## 7. Mode Bands

`Mode Bands` controls which audio range each mode reacts to.

For each mode, you can enable or disable:

- `L`: Low
- `M`: Mid
- `H`: High

Example setups:

- Crown only reacts to `Low` and `Mid`
- Stardust reacts to `High`
- Torus reacts to `Low`
- Webcam Neon Edge reacts to `Mid` and `High`

Use this when too many modes react the same way. It helps separate visual roles.

## 8. BG Mode

`BG Enabled` turns the background layer on or off.

The BG grid contains organic, microscopic, fractal, geometric, and spatial backgrounds. Click a BG tile to select it.

Press the keyboard `ArrowDown` key to move to the next BG Mode. This does not work while typing in an input field.

MIDI can also control BG with:

- `BG Mode Select`
- `BG Mode Step`
- `BG Mode Step Reverse`
- Individual `BG - ...` buttons
- `Toggle BG Mode`

## 9. Animation

### Auto Rotation

When on, the entire scene rotates automatically using `Rotation Speed X` and `Rotation Speed Y`.

When off, use `Manual Rotation X` and `Manual Rotation Y` to set the viewing angle.

### Particle Count

Controls the particle amount for many modes. Maximum is `10000`.

If performance drops, reduce this first.

### Stardust Count

Controls only the Stardust amount. Range is `500` to `10000`.

### Particle Size

Controls point size for particle-based modes.

### Glow Strength

Controls global bloom/glow. Maximum is `0.30`.

### Spark Power

Controls sparkle intensity and point brightness.

## 10. Color

### Hue

Shifts the overall color tone.

### Saturation

Controls color intensity. Lower values are more monochrome. Higher values are more vivid.

## 11. Effects

Effects are applied after the modes and BG render.

### Kaleidoscope

Turns on kaleidoscope folding. `Kaleidoscope Sides` ranges from `0` to `16`.

Moving the slider automatically enables Kaleidoscope. Turn the checkbox off manually when you want to disable it.

### Glitch

Digital offset and tearing style effect.

### RGB Shift

Separates red, green, and blue channels.

### Grunge

Adds dirt/noise texture.

### Earthquake

Shakes the screen. Auto VJ does not use Earthquake by default, but you can control it manually or by MIDI.

### Zoom

Scales the whole output.

### Mirror V and Mirror H

Mirrors vertically or horizontally. Position sliders move the mirror split point.

### Reactive Checkboxes

Each effect has a small reactive checkbox. When checked, the effect reacts automatically to the music.

## 12. Video Input

### Webcam

Starts live camera input.

The Webcam modes and `Video` mode use brightness values from the video. Bright areas come forward, dark areas move back.

### Video File

Loads a local video file and loops it.

### Video Resolution

Controls processing resolution. Higher values show more detail but cost more performance.

Recommended:

- `120` to `240`: safer live performance
- `320`: balanced
- `480`: detailed, heavier

## 13. AI Image

The `AI Image` field generates a background image from a prompt.

To use it:

1. Create a `.env` file with `OPENAI_API_KEY`.
2. Start the local server with `npm start`.
3. Open `http://localhost:5173/vj-final.html`.
4. Enter a prompt.
5. Click `Generate`.

The browser calls `POST /api/generate-image`. The API key stays in the local server and is not written into `vj-final.html`.

See `AI_IMAGE_SETUP.md` for the short setup note.

## 14. Presets and Backup

### Save

Stores the current configuration in browser localStorage.

This includes:

- Main control values
- Enabled modes
- BG mode
- Mode Bands
- MIDI mappings

### Load

Loads the stored configuration from the same browser.

### Export

Downloads the configuration as a JSON file.

Use this before a show or before testing large changes.

### Import

Loads a previously exported JSON file.

Use Export and Import when moving to another computer or browser.

## 15. Controllers

## 15.1 PS5 Controller

Click `PS5 Pad`, then press a button on the controller if the browser asks for interaction.

Current mapping:

- Left stick: manual scene rotation
- Right stick X: Hue
- Right stick Y: Zoom
- L2: Glitch boost
- R2: Zoom and Stardust boost
- L1: Grunge boost
- R1: Earthquake boost
- Cross: toggle Stardust
- Circle: toggle Crown
- Square: toggle Glitch React
- Triangle: toggle Kaleidoscope
- D-pad up/down: Stardust Count up/down
- D-pad left/right: Particle Size down/up

Moving the left stick turns Auto Rotation off automatically.

## 15.2 MIDI and APC40 MK2

Click `MIDI` to connect a Web MIDI device.

### Learn Workflow

1. Choose a target in the MIDI target dropdown.
2. Click `Learn`.
3. Touch the knob, fader, or button on the APC40 MK2.
4. The mapping appears in the MIDI map list.
5. Click `Save` after mapping.

Mapped buttons stay visually active when they are mapped. Mode button LEDs are synced where supported.

### Good APC40 MK2 Mapping Ideas

Use knobs/faders for:

- Particle Count
- Stardust Count
- Particle Size
- Glow Strength
- Spark Power
- Hue
- Saturation
- Glitch
- RGB Shift
- Grunge
- Earthquake
- Zoom
- Kaleidoscope Sides
- BG Mode Select
- Auto Intensity
- Scene Pace
- Mic Sensitivity

Use pads/buttons for:

- Mode toggles such as `Mode - Torus`, `Mode - Crown`, `Mode - Stardust`
- BG toggles such as `BG - Acid Bloom`
- `Toggle Auto VJ`
- `Toggle Safe Mode`
- `Toggle BG Mode`
- `Next Mode`
- `Clear Modes`
- `Panic Reset`

For BG selection with a knob, map a knob to `BG Mode Select`. For stepping through BG choices, map buttons or encoders to `BG Mode Step` and `BG Mode Step Reverse`.

## 16. Recommended Live Workflow

### Before the Show

1. Open the app in Chrome.
2. Connect audio input.
3. Check Bass, Mid, and Treble meters.
4. Connect MIDI or PS5 controller if needed.
5. Load or create your preset.
6. Run `Check`.
7. Turn on Safe Mode if the computer is weak.
8. Export a backup preset JSON.

### During the Show

1. Use Mode buttons for big foreground changes.
2. Use BG Mode for slow world changes.
3. Use Effects for peaks and transitions.
4. Use Auto VJ when you want the app to drive scene changes.
5. Use Panic if the scene becomes too heavy or visually messy.

### Suggested Starting Scene

- Modes: `Particles`, `Stardust`, `Torus`
- BG: `Julia Bloom` or `Acid Bloom`
- Effects: low `Glow Strength`, low `RGB Shift`
- Auto VJ: `Curated`
- Particle Count: `3000` to `6000`

## 17. Troubleshooting

### Mic Does Not React

- Click `Mic` again.
- Check browser microphone permission.
- Raise `Mic Sensitivity`.
- Lower `Noise Gate`.
- Confirm the Bass, Mid, and Treble meters move.
- On iPhone Safari, microphone access requires HTTPS or a true localhost page on the device.

### Webcam Does Not Start

- Check browser camera permission.
- Use Chrome first when testing.
- Camera access requires HTTPS or localhost.
- If using iPhone Safari, opening a Mac `localhost` page from the phone will not count as iPhone localhost.

### Audio Works But Visuals Are Too Weak

- Increase `Particle Size`.
- Increase `Glow Strength`.
- Increase `Spark Power`.
- Raise `Mic Sensitivity`.
- Enable the right Mode Bands for the active modes.

### Visuals Are Too Chaotic

- Disable some modes.
- Turn off `Chaos` Auto Range.
- Reduce Glitch, RGB Shift, Grunge, and Earthquake.
- Use `Panic`.

### Performance Is Slow

- Turn on `Safe Mode`.
- Lower `Particle Count`.
- Lower `Stardust Count`.
- Lower `Video Resolution`.
- Reduce Glow Strength.
- Disable heavy Webcam modes or BG modes.

### Settings Disappear After Reload

- Click `Save` after mapping or editing.
- For important setups, use `Export` and keep the JSON backup.
- Browser private mode or storage clearing can remove localStorage.

### MIDI Is Not Recognized

- Use Chrome.
- Click `MIDI`.
- Reconnect the controller.
- Make sure another app is not exclusively using the controller.
- Use `Learn` again and touch the exact control you want to map.

### AI Image Does Not Generate

- Start the local server with `npm start`.
- Open `http://localhost:5173/vj-final.html`, not the raw file.
- Confirm `.env` contains `OPENAI_API_KEY`.
- Check that the server terminal is still running.

## 18. Files

- `vj-final.html`: main app
- `server.mjs`: local server and AI image endpoint
- `AI_IMAGE_SETUP.md`: short AI image setup note
- `VJ_CYMATICS_3D_MANUAL.md`: this manual
- `skills/vj-cymatics-3d/`: Codex skill notes for continuing development
- `screenshots/`: visual reference screenshots

## 19. Browser Notes

Recommended:

- Desktop Chrome for live performance
- Desktop Edge or Firefox as secondary options

Important requirements:

- WebGL
- Web Audio API
- Web MIDI for MIDI control
- Gamepad API for PS5 controller
- Camera and microphone permission
- HTTPS or localhost for camera and microphone access

## 20. Quick Reference

Best emergency buttons:

- `Panic`: reset to safe state
- `Safe Mode`: reduce rendering load
- `BG Enabled`: remove background layer
- `Clear Modes` from MIDI: remove active foreground modes

Best expressive controls:

- `Particle Size`
- `Glow Strength`
- `Spark Power`
- `Hue`
- `RGB Shift`
- `Glitch`
- `BG Mode Select`
- `Auto Intensity`

Best stable Auto VJ mode:

- `Curated`

Most experimental Auto VJ mode:

- `Chaos`
