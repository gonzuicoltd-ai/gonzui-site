# VJ Cymatics 3D 日本語マニュアル

最終更新日: 2026-06-11

VJ Cymatics 3D は、音や映像に反応して3Dビジュアルを作るブラウザ用のVJツールです。マイク入力、音楽ファイル、ウェブカメラ、動画ファイルを使って、パーティクル、立体、背景エフェクト、万華鏡、グリッチ、MIDI操作、PS5コントローラー操作、Auto VJ などを組み合わせてライブ映像を作れます。

このマニュアルは、ライブ前や本番中に見返しやすいように書いています。まずは「1. すぐ使う」から読んでください。

## 1. すぐ使う

1. `vj-final.html` をブラウザで開きます。
2. `Mic` を押すか、`Audio File` で音楽ファイルを読み込みます。
3. `Visualization Modes` で使いたいモードにチェックを入れます。
4. `Particle Count`、`Particle Size`、`Glow Strength`、`Spark Power` を調整します。
5. 背景を使う場合は `BG Enabled` をオンにして、好きな `BG Mode` を選びます。
6. `Effects` で Kaleidoscope、Glitch、RGB Shift、Grunge、Earthquake、Zoom、Mirror を調整します。
7. 気に入った設定になったら `Save` を押します。

おすすめブラウザは、パソコン版の Chrome です。

AI画像生成を使う場合は、ローカルサーバーで起動します。

```sh
npm start
```

そのあと、ブラウザで次を開きます。

```text
http://localhost:5173/vj-final.html
```

## 2. 画面の見方

中央の大きな画面が、実際に表示されるビジュアルです。

右側の `Control Panel` が操作メニューです。パネルの上部をドラッグすると移動できます。小さくしたり、別ウィンドウに出したりできます。

パネル上部のポップアウトボタンを押すと、操作メニューを別ウィンドウで開けます。別ウィンドウ側の `Hide Main` を押すと、メイン画面から操作メニューを完全に消せます。戻したい時は `Show Main` を押します。

## 3. 音声入力

### Mic

`Mic` はマイク入力を使います。初回はブラウザからマイク許可を求められます。

音は自動で3つに分けられます。

- `Bass`: 低音。キック、ベース、サブの動き
- `Mid`: 中音。声、シンセ、メロディ、曲の芯
- `Treble`: 高音。ハイハット、ノイズ、細かいきらめき

### Audio File

`Audio File` では、MP3、WAV、OGG などの音楽ファイルを読み込めます。

### Mic Sensitivity

マイクの反応の強さを調整します。メーターがあまり動かない時は上げます。反応しすぎる時は下げます。

### Noise Gate

小さな環境音を無視するための設定です。無音なのに反応してしまう時は上げます。小さい音にも反応させたい時は下げます。

## 4. Auto VJ

`Auto Performance` をオンにすると、音に合わせてモード、背景、エフェクトを自動で切り替えます。

### Auto Range

- `Curated`: 安定したセット。通常のライブ向き
- `Wide`: ほぼ全部のモードから選ぶ広めのセット
- `Chaos`: 全モードと背景を強めにランダム運用する実験的なセット

### Auto Intensity

Auto VJ の変化の強さを調整します。高くすると派手になります。

### Scene Pace

シーンが切り替わる速さを調整します。低くするとゆっくり、高くすると忙しく変わります。

## 5. Live Safety

### FPS、Load、Quality

今の動作の重さを見るための表示です。

- `Stable`: 安定しています
- `Busy`: 少し重めですが使えます
- `Heavy`: 重いので設定を軽くした方が安全です

### Safe Mode

`Safe Mode` は、動作を軽くするための安全モードです。フレームレートが落ちる時や、あまり強くないパソコンで使う時にオンにします。

Safe Mode では、主に次の負荷を抑えます。

- パーティクル数
- スターダスト数
- 動画処理の解像度
- 描画の細かさ
- グローの強さ
- ブルーム処理の重さ

### Panic

`Panic` は緊急リセットです。画面が重くなりすぎたり、ビジュアルが暴れすぎたりした時に使います。

押すと次の状態になります。

- Auto VJ オフ
- Safe Mode オン
- BG オフ
- モードは Particles のみに戻る
- 重いエフェクトをリセット

### Check

`Check` は、ブラウザや環境が必要な機能に対応しているかを確認します。

## 6. Visualization Modes

`Visualization Modes` は、画面のメインになる前景ビジュアルです。複数を同時にオンにできます。

### Core

- `Particles`
- `Stardust`
- `Wave`
- `Spiral`
- `Emitter`

### Webcam

ウェブカメラ、または動画ファイルを素材にするモードです。映像入力がない場合でも、真っ黒にならないように仮の動く模様が表示されます。

- `Video`: 映像の明るさを奥行きに変える基本モード
- `Webcam Depth Cloud`: やわらかい奥行きの点群
- `Webcam Neon Edge`: 輪郭をネオン風に出すモード
- `Webcam Thermal`: サーモグラフィ風の色表現
- `Webcam Kaleido`: 映像を万華鏡のように折り畳むモード
- `Webcam Silhouette`: 人影や輪郭を強調するモード
- `Webcam Liquid`: 液体のように歪む映像パーティクル
- `Webcam Voxel`: ブロック状に見える奥行き表現
- `Webcam Ghost Delay`: 残像や遅延エコーのある映像表現

`Auto Rotation` をオフにすると、Webcam系モードは勝手に回転しません。

### Geometry

- `Torus`
- `TorusKnot`
- `Icosahedron`
- `Octahedron`
- `Dodecahedron`
- `Sphere Mesh`
- `Triangle`
- `Orbit System`
- `Cymatic Plate`
- `Knot Cloud`

### Fractal

- `Fractal Tree`
- `Infinite Fractal`
- `Julia Geodes`
- `Flower Mandala`
- `Magic Circles`
- `Star Gate`
- `Black Hole`

### Energy

- `Laser Grid`
- `DNA Helix`
- `Plasma Ball`
- `Shard Burst`
- `Ribbon Flow`
- `Vortex Echo`
- `Particle Fountain`
- `Electric Web`
- `Pulse Rings`
- `Comet Field`

### Worlds

- `Crown`
- `Nebula`
- `Crystal Cave`
- `Audio Tunnel`
- `Rain Matrix`
- `Liquid Metal`
- `Wire Mountain`
- `Solar Flare`
- `Cathedral Lines`
- `Mirror City`
- `Data Storm`

## 7. Mode Bands

`Mode Bands` では、それぞれのモードがどの音域に反応するかを設定できます。

各モードごとに次をオン、オフできます。

- `L`: Low、低音
- `M`: Mid、中音
- `H`: High、高音

例:

- Crown は `Low` と `Mid` だけに反応させる
- Stardust は `High` だけに反応させる
- Torus は `Low` に反応させる
- Webcam Neon Edge は `Mid` と `High` に反応させる

モードをたくさん重ねた時に、全部が同じ動きになってしまうのを避けられます。

## 8. BG Mode

`BG Enabled` をオンにすると、背景レイヤーが表示されます。

BG Mode には、有機的な模様、顕微鏡のような世界、フラクタル、幾何学模様、立体空間風の背景が入っています。

BGのボタンを押すと、その背景に切り替わります。

キーボードの `ArrowDown` を押すと、次の BG Mode に進みます。入力欄に文字を打っている時は反応しません。

MIDIからも BG を操作できます。

- `BG Mode Select`
- `BG Mode Step`
- `BG Mode Step Reverse`
- 個別の `BG - ...` ボタン
- `Toggle BG Mode`

## 9. Animation

### Auto Rotation

オンにすると、シーン全体が自動で回転します。回転速度は `Rotation Speed X` と `Rotation Speed Y` で調整します。

オフにすると、`Manual Rotation X` と `Manual Rotation Y` で角度を固定できます。

### Particle Count

多くのモードで使われるパーティクル数です。最大は `10000` です。

重い時は、まずここを下げるのがおすすめです。

### Stardust Count

Stardust専用の星の量です。範囲は `500` から `10000` です。

### Particle Size

点の大きさを調整します。

### Glow Strength

全体の光り方を調整します。最大値は `0.30` です。

### Spark Power

きらめきや点の明るさを調整します。

## 10. Color

### Hue

全体の色味を変えます。

### Saturation

色の鮮やかさを変えます。下げるとモノクロ寄りになり、上げると派手になります。

## 11. Effects

エフェクトは、モードや背景を描いたあとに画面全体へかかります。

### Kaleidoscope

万華鏡エフェクトです。`Kaleidoscope Sides` は `0` から `16` まで調整できます。

スライダーを動かすと、自動で Kaleidoscope がオンになります。消したい時はチェックボックスをオフにしてください。

### Glitch

デジタルノイズや画面のズレを加えます。

### RGB Shift

赤、緑、青の色チャンネルをずらします。

### Grunge

汚れやざらつきのある質感を加えます。

### Earthquake

画面を揺らします。Auto VJ では標準では使われませんが、手動やMIDIで操作できます。

### Zoom

画面全体を拡大、縮小します。

### Mirror V と Mirror H

縦方向、横方向の鏡面エフェクトです。位置スライダーでミラーの境目を動かせます。

### Reactive チェックボックス

各エフェクト横の小さなチェックボックスをオンにすると、そのエフェクトが音に反応します。

## 12. Video Input

### Webcam

ライブカメラ入力を開始します。

Webcam系モードと `Video` モードでは、映像の明るさを使います。明るい部分は手前に、暗い部分は奥に動きます。

### Video File

ローカルの動画ファイルを読み込み、ループ再生します。

### Video Resolution

映像処理の解像度です。高くすると細かく表示できますが、その分重くなります。

おすすめ:

- `120` から `240`: ライブで安全
- `320`: バランスが良い
- `480`: 細かいが重め

## 13. AI Image

`AI Image` では、入力した文章から背景画像を生成できます。

使い方:

1. `.env` ファイルに `OPENAI_API_KEY` を設定します。
2. `npm start` でローカルサーバーを起動します。
3. `http://localhost:5173/vj-final.html` を開きます。
4. プロンプトを入力します。
5. `Generate` を押します。

画像生成は `POST /api/generate-image` を使います。APIキーはローカルサーバー側に置かれ、`vj-final.html` には書き込まれません。

短いセットアップ手順は `AI_IMAGE_SETUP.md` にもあります。

## 14. Presets and Backup

### Save

現在の設定をブラウザ内に保存します。

保存される主な内容:

- 各スライダーやチェックボックスの値
- オンになっているモード
- BG Mode
- Mode Bands
- MIDIマッピング

### Load

同じブラウザに保存された設定を読み込みます。

### Export

設定を JSON ファイルとして書き出します。

ライブ前や大きく設定を変える前には、Export しておくのがおすすめです。

### Import

Export した JSON ファイルを読み込みます。

別のパソコンや別のブラウザに設定を移したい時に使います。

## 15. Controllers

## 15.1 PS5コントローラー

`PS5 Pad` を押し、必要であればコントローラーのボタンを押してブラウザに認識させます。

現在の割り当て:

- 左スティック: シーンの手動回転
- 右スティック左右: Hue
- 右スティック上下: Zoom
- L2: Glitch を一時的に強くする
- R2: Zoom と Stardust を一時的に強くする
- L1: Grunge を一時的に強くする
- R1: Earthquake を一時的に強くする
- Cross: Stardust のオン、オフ
- Circle: Crown のオン、オフ
- Square: Glitch React のオン、オフ
- Triangle: Kaleidoscope のオン、オフ
- D-pad 上下: Stardust Count を増減
- D-pad 左右: Particle Size を増減

左スティックを動かすと、Auto Rotation は自動でオフになります。

## 15.2 MIDI と APC40 MK2

`MIDI` を押すと、Web MIDI対応のコントローラーを接続できます。

### Learn の使い方

1. MIDIターゲットのリストから、割り当てたい操作を選びます。
2. `Learn` を押します。
3. APC40 MK2 のノブ、フェーダー、ボタンを触ります。
4. MIDIマップ一覧に割り当てが表示されます。
5. 割り当てが終わったら `Save` を押します。

マッピング済みのボタンは、何が割り当てられているか分かりやすいように表示されます。対応している場合は、モードボタンのLEDも同期します。

### APC40 MK2 のおすすめ割り当て

ノブやフェーダーに向いているもの:

- Particle Count
- Stardust Count
- Particle Size
- Glow Strength
- Spark Power
- Hue
- Saturation
- Glitch
- RGB Shift
- Grunge
- Earthquake
- Zoom
- Kaleidoscope Sides
- BG Mode Select
- Auto Intensity
- Scene Pace
- Mic Sensitivity

パッドやボタンに向いているもの:

- `Mode - Torus`、`Mode - Crown`、`Mode - Stardust` などのモード切り替え
- `BG - Acid Bloom` などの背景切り替え
- `Toggle Auto VJ`
- `Toggle Safe Mode`
- `Toggle BG Mode`
- `Next Mode`
- `Clear Modes`
- `Panic Reset`

BGをノブで選びたい場合は、ノブに `BG Mode Select` を割り当てます。ボタンで順番に切り替えたい場合は、`BG Mode Step` と `BG Mode Step Reverse` を割り当てます。

## 16. ライブでのおすすめ手順

### 本番前

1. Chromeでアプリを開きます。
2. 音声入力を接続します。
3. Bass、Mid、Treble のメーターが動くか確認します。
4. 必要であれば MIDI や PS5 コントローラーを接続します。
5. プリセットを読み込むか、新しく設定します。
6. `Check` を実行します。
7. パソコンが弱い場合は Safe Mode をオンにします。
8. 設定を JSON で Export しておきます。

### 本番中

1. Mode ボタンで大きな前景変化を作ります。
2. BG Mode で空間全体の雰囲気を変えます。
3. Effects は盛り上がりや切り替え時に使います。
4. 自動で展開させたい時は Auto VJ を使います。
5. 重くなったり画面が荒れすぎたりしたら Panic を押します。

### 最初におすすめのシーン

- Modes: `Particles`、`Stardust`、`Torus`
- BG: `Julia Bloom` または `Acid Bloom`
- Effects: `Glow Strength` 低め、`RGB Shift` 低め
- Auto VJ: `Curated`
- Particle Count: `3000` から `6000`

## 17. トラブル対応

### マイクが反応しない

- `Mic` をもう一度押します。
- ブラウザのマイク許可を確認します。
- `Mic Sensitivity` を上げます。
- `Noise Gate` を下げます。
- Bass、Mid、Treble のメーターが動くか確認します。
- iPhone Safari では、マイク利用に HTTPS またはその端末上の localhost が必要です。

### Webcam が起動しない

- ブラウザのカメラ許可を確認します。
- まずは Chrome で試します。
- カメラ利用には HTTPS または localhost が必要です。
- iPhone Safari では、Mac側の localhost をiPhoneから開いても、iPhone自身の localhost ではありません。

### 音は入っているのに映像が弱い

- `Particle Size` を上げます。
- `Glow Strength` を上げます。
- `Spark Power` を上げます。
- `Mic Sensitivity` を上げます。
- Mode Bands で、使いたい音域がオンになっているか確認します。

### 映像が派手すぎる、荒れすぎる

- オンになっているモードを減らします。
- Auto Range を `Chaos` 以外にします。
- Glitch、RGB Shift、Grunge、Earthquake を下げます。
- `Panic` を押します。

### 動作が重い

- `Safe Mode` をオンにします。
- `Particle Count` を下げます。
- `Stardust Count` を下げます。
- `Video Resolution` を下げます。
- `Glow Strength` を下げます。
- 重い Webcam モードや BG モードを減らします。

### リロードしたら設定が消えた

- 設定後に `Save` を押してください。
- 大事な設定は `Export` で JSON バックアップを残してください。
- シークレットモードやブラウザのストレージ削除で、保存内容が消えることがあります。

### MIDI が認識されない

- Chrome を使います。
- `MIDI` を押します。
- コントローラーを接続し直します。
- 他のアプリがコントローラーを専有していないか確認します。
- `Learn` をもう一度押し、割り当てたい操作子を触ります。

### AI Image が動かない

- `npm start` でローカルサーバーを起動します。
- raw file ではなく `http://localhost:5173/vj-final.html` を開きます。
- `.env` に `OPENAI_API_KEY` が入っているか確認します。
- サーバーのターミナルが動き続けているか確認します。

## 18. ファイル一覧

- `vj-final.html`: メインアプリ
- `server.mjs`: ローカルサーバーとAI画像生成用API
- `AI_IMAGE_SETUP.md`: AI画像生成の短いセットアップ手順
- `VJ_CYMATICS_3D_MANUAL.md`: 英語版マニュアル
- `VJ_CYMATICS_3D_MANUAL_JA.md`: 日本語版マニュアル
- `skills/vj-cymatics-3d/`: 今後の開発用メモ
- `screenshots/`: 画面確認用のスクリーンショット

## 19. ブラウザについて

おすすめ:

- ライブ本番はパソコン版 Chrome
- Edge や Firefox は予備候補

必要な機能:

- WebGL
- Web Audio API
- Web MIDI
- Gamepad API
- カメラとマイクの許可
- カメラ、マイク利用時は HTTPS または localhost

## 20. 早見表

困った時に使うもの:

- `Panic`: 安全な状態に戻す
- `Safe Mode`: 描画を軽くする
- `BG Enabled`: 背景を消す
- MIDIの `Clear Modes`: 前景モードを消す

表現を作りやすい操作:

- `Particle Size`
- `Glow Strength`
- `Spark Power`
- `Hue`
- `RGB Shift`
- `Glitch`
- `BG Mode Select`
- `Auto Intensity`

一番安定して使いやすい Auto VJ:

- `Curated`

一番実験的な Auto VJ:

- `Chaos`
